struct obj* copy(struct obj *form);

void bresenham(int, int, int, int);
void midPtCircle(int, int, int);
void midPtElipse(int, int, int, int);
